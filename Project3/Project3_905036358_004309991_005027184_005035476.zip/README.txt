README.txt

Python version: 
Python 3.6

required package: 

numpy
nltk
sklearn
pickle
tempfile
heapq
Surprise
jupyter notebook

instructions: 

!. install all the required packages and python

2. navigate to the dir containing the code and report

3. open jupyter notebook at that dir

4. open the code notebook file

5. run it using run all

6. the outputs will come out(really slow, maybe 20 minutes at top)